import pool from '../config/database.js';

export class HistoryRepository {
  async findAll() {
    const result = await pool.query(
      'SELECT * FROM search_history ORDER BY created_at DESC LIMIT 50'
    );
    return result.rows.map(row => ({
      id: row.id,
      originalQuery: row.original_query,
      parsedParams: row.parsed_params,
      expandedKeywords: row.expanded_keywords,
      booleanQuery: row.boolean_query,
      urls: row.urls,
      filtersApplied: row.filters_applied,
      createdAt: row.created_at
    }));
  }

  async add(entry) {
    const { originalQuery, parsedParams, expandedKeywords, booleanQuery, urls, filtersApplied } = entry;
    await pool.query(
      `INSERT INTO search_history
      (original_query, parsed_params, expanded_keywords, boolean_query, urls, filters_applied)
      VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        originalQuery,
        JSON.stringify(parsedParams),
        expandedKeywords,
        booleanQuery,
        JSON.stringify(urls),
        filtersApplied
      ]
    );
  }

  async deleteById(id) {
    await pool.query('DELETE FROM search_history WHERE id = $1', [id]);
  }

  async clear() {
    await pool.query('DELETE FROM search_history');
  }
}
